"""Signal Space auditable research runtime."""

__version__ = "0.1.0"
