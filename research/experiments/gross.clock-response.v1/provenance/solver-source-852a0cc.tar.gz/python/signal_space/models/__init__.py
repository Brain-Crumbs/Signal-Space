"""Versioned mathematical model definitions."""
