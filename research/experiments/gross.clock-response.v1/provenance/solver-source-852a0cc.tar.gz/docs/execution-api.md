# Shared execution boundary

Engineering foundation for Paper I §11; parent #1, task #3. This adds no physical equations. The original Paper III attachment is background only and is not an implementation source for this task.

Both adapters call `execute({ runId, mode: 'inspect', scenario }, { signal })` from `@signal-space/sim`. It is an async generator of structured-cloneable `RunEvent` values, independent of React and Node APIs. A run owns a cloned input before its first progress yield. The nested history, observation, solver, intervention and unit fields are structurally constrained at the runtime boundary. JSON Schema validation precedes semantic validation, so malformed collections cannot reach the semantic validator. Failures contain codes, messages and field paths.

| Event       | Meaning                                                                                                          |
| ----------- | ---------------------------------------------------------------------------------------------------------------- |
| `progress`  | Fraction in [0,1] and validating/preparing stage                                                                 |
| `snapshot`  | Detached initial `Snapshot` at t=0, including supplied history, filters, pending packets/responses and RNG state |
| `completed` | Terminal inspection success; explicitly identifies inspect mode                                                  |
| `cancelled` | Terminal cooperative cancellation                                                                                |
| `failed`    | Terminal structured failure; invalid request/scenario, internal error or worker busy                             |

`WorkerCommand` is a discriminated union of run and cancel. Cancellation is scoped to `runId`; a different ID cannot abort an active request. Each worker adapter handles one run and rejects overlapping requests as BUSY. Use a unique ID for each request. The UI creates a worker per run and terminates it on completion, failure or unmount. It ignores responses for stale IDs.

The engine yields to the task queue between preparation stages so worker cancel messages can be delivered. Synchronous validation itself is not interruptible; large inputs may postpone cancellation until the next stage. Callers must consume the generator to a terminal event (or deliberately stop it). An abort before completion produces exactly one cancelled event and no completed event. A snapshot may already have been delivered; it is still the supplied preparation, not evidence of a completed simulation.

The smoke fixtures only validate plumbing and expose the user-supplied initial state. A snapshot at t=0 is not a solved trajectory, restart algorithm, evolved history, event realization, observer record or completed A–I protocol. The `envelope` mode now provides actual integration and complete evolving history as described below; T04 owns stochastic scheduling and T07 owns run manifests/checkpoints/provenance. No tolerance or convergence claim is made here.

Source-first private workspaces are bundled by Vite/esbuild and run in development through tsx. Strict TypeScript applies to new TS code; the T01 JavaScript semantic validator is exposed through declarations. ESLint forbids Node/React imports in shared source and Node/CLI imports in the web app.

Review hardening: closed scenario objects reject undeclared fields instead of copying them into typed snapshots. The history and filter maps must contain exactly the scenario node IDs. Pending packets at t=0 require finite emissionTime <= 0 <= arrivalTime with arrivalTime > emissionTime. Arrivals exactly at zero are queued for initial delivery; they are not already included in receiver filters. These checks validate preparation only, not propagation against the future solver. Declared unknown response payloads and intervention values remain unrestricted.

History endpoint phase/frequency must agree exactly with the initial node state, and pending response targets must belong to the scenario. Inspection rejects inconsistent preparations instead of choosing one copy as authoritative.

Failure to clone caller input produces `INVALID_SCENARIO` with a field-level detail, before any snapshot or progress is exposed. `INTERNAL` remains reserved for failures after the input-cloning boundary. Mirror preparation history includes the ideal-reflection round trip `2d/c0`.

SharedArrayBuffer values and views backed by shared memory are rejected, including within nested containers, because structured cloning cannot detach their backing storage. Ordinary ArrayBuffers and typed views remain supported and are owned before the first progress event.

## T03 envelope execution (#4)

`execute({ runId, mode: 'envelope', scenario, until, envelope?, resume? })` integrates deterministic envelopes through absolute time `until`. See [numerical contract, preparation and restart](envelope-solver.md). The entire request, including options and checkpoint, is cloned before the first progress yield and rejects shared memory. `inspect` is unchanged.

Additional events are `envelope-sample` (physical sample plus tick crossings), `envelope-snapshot` (versioned complete evolved history), and progress stage `integrating`. Completion explicitly reports `mode: 'envelope'`. Numerical/configuration errors use `INVALID_REQUEST`, `INVALID_HISTORY`, `UNSUPPORTED_MODEL` or `NUMERICAL_FAILURE`; they do not emit completion. Cancellation during evolution emits the last accepted checkpoint before its terminal cancellation event. CLI `--until` and the production worker consume the same implementation.

T04 adds `mode: 'packets'`, explicit `packets: { seed }`, and absolute `until`. It emits simulator-only `packet-sample`, complete `packet-snapshot`, and a terminal `completed`, `incomplete`, `cancelled` or `failed`. Resume uses `packetResume`; envelope and packet options/checkpoints cannot be interchanged. See [packet engine](packet-engine.md) for state, seeding, resource budgets, supported preparations and same-runtime replay limits.
